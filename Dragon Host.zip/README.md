Bot de Hospedagem
créditos: 
- sozan
- discord.gg/11kvazamentoss
se fkr vazar deixe créditos


# CONFIGURAÇÕES
- Você deve mudar o *config.json* antes de usar o bot.
- É possivel aumentar o máximo de aplicações no *config.json*
- Caso encontre algum erro, entre em contado cpm o sozan na 11k ou na royal vazamentos.
- Abra ticket e me marca