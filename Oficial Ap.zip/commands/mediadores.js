const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const emojis = require('../DataBaseJson/emojis.json');
const filaPath = path.join(__dirname, '../DataBaseJson/mediadores.json');
const configPath = path.join(__dirname, '../config.json');
const permsPath = path.join(__dirname, '../DataBaseJson/perms.json');
const cargosPath = path.join(__dirname, '../DataBaseJson/mediador.json');

const CARGO_MEDIADOR_ESPECIAL = '1462181979930755283';

function isOwnerOrPermitted(userId) {
  try {
    const config = JSON.parse(fs.readFileSync(configPath));
    if (config.ownerId === userId) return true;
    if (fs.existsSync(permsPath)) {
      const perms = JSON.parse(fs.readFileSync(permsPath));
      return Object.keys(perms).includes(userId);
    }
    return false;
  } catch {
    return false;
  }
}

function hasMediadorRole(member) {
  if (member.roles.cache.has(CARGO_MEDIADOR_ESPECIAL)) return true;
  try {
    if (fs.existsSync(cargosPath)) {
      const cargos = JSON.parse(fs.readFileSync(cargosPath, 'utf-8'));
      return member.roles.cache.some(role => cargos.includes(role.id));
    }
  } catch (e) {}
  return false;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mediadores')
    .setDescription('Veja ou entre na fila de mediadores.'),
  async execute(interaction) {
    const member = interaction.member;
    const canUse = isOwnerOrPermitted(interaction.user.id) || hasMediadorRole(member);

    if (!canUse) {
      return interaction.reply({
        content: '❌ Apenas mediadores ou o dono do bot podem usar este comando!',
        ephemeral: true
      });
    }

    let fila = [];
    if (fs.existsSync(filaPath)) {
      try {
        const raw = fs.readFileSync(filaPath, 'utf-8');
        const parsed = JSON.parse(raw);
        fila = Array.isArray(parsed) ? parsed : (parsed.fila || []);
      } catch (e) {
        fila = [];
      }
    }

    let desc = fila.length > 0
      ? fila.map((u, i) => `**${i + 1}.** <@${u}>`).join('\n')
      : 'Nenhum mediador na fila.';

    const embed = new EmbedBuilder()
      .setTitle(`${emojis.information_emoji || 'ℹ️'} Painel de Mediadores`)
      .setDescription('Entre ou saia da fila de mediadores usando os botões abaixo.\n\nAo entrar na fila, você será registrado nos logs das partidas ativas.')
      .addFields({ name: `${emojis._people_emoji || '👥'} Mediadores na Fila (${fila.length}):`, value: desc })
      .setColor(0x2ecc71);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('entrar_fila')
        .setLabel('Entrar na fila')
        .setStyle(ButtonStyle.Success)
        .setEmoji(emojis.member_add_emoji || '➕'),
      new ButtonBuilder()
        .setCustomId('sair_fila')
        .setLabel('Sair da fila')
        .setStyle(ButtonStyle.Danger)
        .setEmoji(emojis.member_remove_emoji || '➖')
    );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: false });
  }
};
