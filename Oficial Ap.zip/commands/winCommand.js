const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const usersPath = path.join(__dirname, '../DataBaseJson/usersinfo.json');
const mediadoresPath = path.join(__dirname, '../DataBaseJson/mediadores.json');
const configPath = path.join(__dirname, '../config.json');
const configPontosPath = path.join(__dirname, '../DataBaseJson/configuracoes.json');
const colorPath = path.join(__dirname, '../DataBaseJson/bot_color.json');
const filasDadosPath = path.join(__dirname, '../DataBaseJson/filasDados.json');

function isMediator(member) {
  try {
    const mediadorRoleIds = JSON.parse(fs.readFileSync(mediadoresPath, 'utf-8'));
    if (mediadorRoleIds.some(roleId => member.roles.cache.has(roleId))) return true;
  } catch (e) {}
  const { PermissionsBitField } = require('discord.js');
  return member.permissions.has(PermissionsBitField.Flags.ManageChannels);
}

function isOwner(userId) {
  try {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    return config.ownerId === userId;
  } catch (e) { return false; }
}

function getPontosConfig() {
  try {
    const config = JSON.parse(fs.readFileSync(configPontosPath, 'utf-8'));
    const pontos = parseInt(config.pontos_vitoria);
    return isNaN(pontos) || pontos < 1 ? 3 : pontos;
  } catch (e) { return 3; }
}

function getCorEscolhida() {
  try {
    const data = JSON.parse(fs.readFileSync(colorPath, 'utf-8'));
    return data.cor || '#00FF00';
  } catch (e) { return '#00FF00'; }
}

function getUserData(userId) {
  let db = {};
  if (fs.existsSync(usersPath)) {
    try { db = JSON.parse(fs.readFileSync(usersPath, 'utf-8')); } catch (e) {}
  }
  if (!db[userId]) {
    db[userId] = { id: userId, vitorias: 0, derrotas: 0, pontos: 0, partidas: 0 };
  }
  return db[userId];
}

function saveUserData(userData) {
  let db = {};
  if (fs.existsSync(usersPath)) {
    try { db = JSON.parse(fs.readFileSync(usersPath, 'utf-8')); } catch (e) {}
  }
  db[userData.id] = userData;
  fs.writeFileSync(usersPath, JSON.stringify(db, null, 2), 'utf-8');
}

module.exports = {
  name: 'win',
  description: 'Define o vencedor de uma partida. Uso: !win @vencedor [@perdedor]',
  async execute(message, args) {
    if (message.author.bot) return;

    if (!isMediator(message.member) && !isOwner(message.author.id)) {
      return message.reply('❌ Apenas mediadores ou o dono do bot podem usar este comando.');
    }

    const mentioned = message.mentions.users;
    const vencedor = mentioned.first();

    if (!vencedor) {
      return message.reply('❌ Uso correto: `!win @vencedor [@perdedor]`');
    }

    let perdedorUser = null;
    if (mentioned.size >= 2) {
      const mentionedArr = Array.from(mentioned.values());
      perdedorUser = mentionedArr[1];
    } else {
      let filasDados = {};
      if (fs.existsSync(filasDadosPath)) {
        try { filasDados = JSON.parse(fs.readFileSync(filasDadosPath, 'utf-8')); } catch (e) {}
      }
      const partida = filasDados[message.channel.id];
      if (partida && partida.jogadores) {
        const jogadoresIDs = partida.jogadores.map(j => (typeof j === 'object' && j.id) ? j.id : j);
        const perdedorId = jogadoresIDs.find(id => id !== vencedor.id);
        if (perdedorId) {
          perdedorUser = await message.client.users.fetch(perdedorId).catch(() => null);
        }
      }
    }

    const pontos = getPontosConfig();
    const corEscolhida = getCorEscolhida();

    const winner = getUserData(vencedor.id);
    winner.vitorias = (winner.vitorias || 0) + 1;
    winner.pontos = (winner.pontos || 0) + pontos;
    winner.partidas = (winner.partidas || 0) + 1;
    winner.consecutivas = (winner.consecutivas || 0) + 1;
    saveUserData(winner);

    let loser = null;
    if (perdedorUser) {
      loser = getUserData(perdedorUser.id);
      loser.derrotas = (loser.derrotas || 0) + 1;
      loser.partidas = (loser.partidas || 0) + 1;
      loser.consecutivas = 0;
      saveUserData(loser);
    }

    const embed = new EmbedBuilder()
      .setTitle('🏆 Vencedor Definido!')
      .setColor(corEscolhida)
      .setThumbnail(vencedor.displayAvatarURL())
      .setDescription(
        `A partida foi concluída!\n\n` +
        `**🏆 Vencedor:** <@${vencedor.id}>\n` +
        (perdedorUser ? `**💔 Perdedor:** <@${perdedorUser.id}>\n\n` : '\n') +
        `**Pontos concedidos:** +${pontos} pontos`
      )
      .addFields(
        {
          name: '📊 Estatísticas do Vencedor',
          value: `Vitórias: **${winner.vitorias}**\nPontos Totais: **${winner.pontos}**`,
          inline: true
        }
      );

    if (loser) {
      embed.addFields({
        name: '📊 Estatísticas do Perdedor',
        value: `Derrotas: **${loser.derrotas}**\nPontos Totais: **${loser.pontos || 0}**`,
        inline: true
      });
    }

    embed.setFooter({ text: `Definido por ${message.author.tag}` })
      .setTimestamp();

    await message.channel.send({ embeds: [embed] });

    setTimeout(() => {
      message.delete().catch(() => {});
    }, 3000);
  }
};
