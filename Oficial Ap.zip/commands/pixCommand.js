const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');

const pagamentosPath = path.join(__dirname, '../DataBaseJson/pagamentos.json');
const mediadoresPath = path.join(__dirname, '../DataBaseJson/mediadores.json');
const configPath = path.join(__dirname, '../config.json');

function isMediator(member) {
  try {
    const mediadorRoleIds = JSON.parse(fs.readFileSync(mediadoresPath, 'utf-8'));
    if (mediadorRoleIds.some(roleId => member.roles.cache.has(roleId))) return true;
  } catch (e) {}
  const { PermissionsBitField } = require('discord.js');
  return member.permissions.has(PermissionsBitField.Flags.ManageChannels);
}

function isOwner(userId) {
  try {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    return config.ownerId === userId;
  } catch (e) { return false; }
}

function getPagamento(userId) {
  try {
    const data = JSON.parse(fs.readFileSync(pagamentosPath, 'utf-8'));
    return data[userId] || null;
  } catch (e) { return null; }
}

function savePagamento(userId, data) {
  try {
    let db = {};
    if (fs.existsSync(pagamentosPath)) {
      db = JSON.parse(fs.readFileSync(pagamentosPath, 'utf-8'));
    }
    db[userId] = data;
    fs.writeFileSync(pagamentosPath, JSON.stringify(db, null, 2), 'utf-8');
    return true;
  } catch (e) { return false; }
}

module.exports = {
  name: 'pix',
  description: 'Veja ou defina a chave PIX. Uso: !pix [set <chave>|@usuario]',
  async execute(message, args) {
    if (message.author.bot) return;

    const subCmd = args[0];

    if (subCmd === 'set') {
      if (!isMediator(message.member) && !isOwner(message.author.id)) {
        return message.reply('❌ Apenas mediadores ou o dono do bot podem definir a chave PIX.');
      }

      const chave = args.slice(1).join(' ');
      if (!chave) {
        return message.reply('❌ Uso correto: `!pix set <chave>`');
      }

      const existing = getPagamento(message.author.id) || {};
      existing.chave_pix = chave;
      savePagamento(message.author.id, existing);

      const embed = new EmbedBuilder()
        .setTitle('✅ Chave PIX Definida')
        .setColor(0x2ecc71)
        .setDescription('Sua chave PIX foi atualizada com sucesso!')
        .addFields({ name: '🔑 Nova Chave', value: `\`${chave}\``, inline: false })
        .setTimestamp();

      return message.channel.send({ embeds: [embed] });
    }

    const mentioned = message.mentions.users.first();
    const targetId = mentioned ? mentioned.id : message.author.id;

    let displayName = mentioned ? mentioned.username : message.author.username;
    try {
      const member = await message.guild.members.fetch(targetId);
      displayName = member.displayName;
    } catch (e) {}

    const pagamento = getPagamento(targetId);

    if (!pagamento?.chave_pix) {
      return message.reply(`❌ Nenhuma chave PIX configurada para <@${targetId}>.`);
    }

    const chave = pagamento.chave_pix;

    let qrBuffer;
    try {
      qrBuffer = await QRCode.toBuffer(chave, {
        width: 300,
        margin: 2,
        color: { dark: '#000000', light: '#FFFFFF' }
      });
    } catch (e) {
      return message.reply('❌ Erro ao gerar o QR Code.');
    }

    const attachment = new AttachmentBuilder(qrBuffer, { name: 'qrcode.png' });

    const embed = new EmbedBuilder()
      .setTitle(`🐍 Chave PIX — ${displayName.toUpperCase()} 🐍`)
      .setColor(0x2ecc71)
      .setDescription(`✅ **Chave PIX:**\n\`${chave}\``)
      .setImage('attachment://qrcode.png')
      .setFooter({ text: 'Copie a chave acima para realizar o pagamento.' })
      .setTimestamp();

    const tempButton = new ButtonBuilder()
      .setCustomId('copiar_pix_temp')
      .setLabel('🐍 Copiar Chave PIX')
      .setStyle(ButtonStyle.Success);

    const row = new ActionRowBuilder().addComponents(tempButton);

    const sentMessage = await message.channel.send({
      embeds: [embed],
      files: [attachment],
      components: [row]
    });

    if (!global.pixKeys) global.pixKeys = {};
    global.pixKeys[sentMessage.id] = chave;

    const realButton = new ButtonBuilder()
      .setCustomId(`copiar_pix_${sentMessage.id}`)
      .setLabel('🐍 Copiar Chave PIX')
      .setStyle(ButtonStyle.Success);

    const updatedRow = new ActionRowBuilder().addComponents(realButton);
    await sentMessage.edit({ components: [updatedRow] });
  }
};
