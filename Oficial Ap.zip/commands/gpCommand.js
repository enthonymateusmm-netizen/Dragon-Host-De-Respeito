const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const usersPath = path.join(__dirname, '../DataBaseJson/usersinfo.json');
const mediadoresPath = path.join(__dirname, '../DataBaseJson/mediadores.json');
const configPath = path.join(__dirname, '../config.json');

function isMediator(member) {
  try {
    const mediadorRoleIds = JSON.parse(fs.readFileSync(mediadoresPath, 'utf-8'));
    if (mediadorRoleIds.some(roleId => member.roles.cache.has(roleId))) return true;
  } catch (e) {}
  const { PermissionsBitField } = require('discord.js');
  return member.permissions.has(PermissionsBitField.Flags.ManageChannels);
}

function isOwner(userId) {
  try {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    return config.ownerId === userId;
  } catch (e) { return false; }
}

function getUserData(userId) {
  let db = {};
  if (fs.existsSync(usersPath)) {
    try { db = JSON.parse(fs.readFileSync(usersPath, 'utf-8')); } catch (e) {}
  }
  if (!db[userId]) {
    db[userId] = { id: userId, vitorias: 0, derrotas: 0, pontos: 0, partidas: 0 };
  }
  return { db, user: db[userId] };
}

function saveDB(db) {
  try {
    fs.writeFileSync(usersPath, JSON.stringify(db, null, 2), 'utf-8');
    return true;
  } catch (e) { return false; }
}

module.exports = {
  name: 'gp',
  description: 'Dá ou remove pontos de um usuário. Uso: !gp @usuario <+/-valor>',
  async execute(message, args) {
    if (message.author.bot) return;

    if (!isMediator(message.member) && !isOwner(message.author.id)) {
      return message.reply('❌ Apenas mediadores ou o dono do bot podem usar este comando.');
    }

    const mentioned = message.mentions.users.first();
    if (!mentioned) {
      return message.reply('❌ Uso correto: `!gp @usuario <valor>` (ex: `!gp @jogador 10` ou `!gp @jogador -5`)');
    }

    const valorStr = args[1] || args[2];
    if (!valorStr) {
      return message.reply('❌ Informe o valor de pontos. Uso: `!gp @usuario <valor>`');
    }

    const valor = parseInt(valorStr, 10);
    if (isNaN(valor)) {
      return message.reply('❌ O valor deve ser um número. Ex: `!gp @usuario 10` ou `!gp @usuario -5`');
    }

    const { db, user } = getUserData(mentioned.id);
    const pontosAntes = user.pontos || 0;
    user.pontos = Math.max(0, pontosAntes + valor);
    db[mentioned.id] = user;
    saveDB(db);

    const acao = valor >= 0 ? `+${valor}` : `${valor}`;
    const cor = valor >= 0 ? 0x2ecc71 : 0xed4245;

    const embed = new EmbedBuilder()
      .setTitle('🏆 Pontos Atualizados')
      .setColor(cor)
      .setThumbnail(mentioned.displayAvatarURL())
      .addFields(
        { name: '👤 Jogador', value: `<@${mentioned.id}>`, inline: true },
        { name: '📊 Variação', value: `\`${acao} pontos\``, inline: true },
        { name: '🏅 Pontos Antes', value: `\`${pontosAntes}\``, inline: true },
        { name: '🏅 Pontos Agora', value: `\`${user.pontos}\``, inline: true }
      )
      .setFooter({ text: `Modificado por ${message.author.username}` })
      .setTimestamp();

    return message.channel.send({ embeds: [embed] });
  }
};
