const { UploadEmojis } = require('../FunctionEmojis/EmojisFunction');
const { ActivityType } = require('discord.js');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log(`Bot está online! Logado como ${client.user.tag}`);
        client.user.setPresence({
          activities: [{ name: 'Aposte aqui na Aurion', type: ActivityType.Playing }],
          status: 'online'
        });
        
        console.log('Carregando emojis...');
        try {
            await UploadEmojis(client);
            console.log('Emojis carregados com sucesso!');
        } catch (e) {
            console.error('Erro ao carregar emojis:', e.message);
        }
    },
};
