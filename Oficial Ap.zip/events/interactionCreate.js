const fs = require('fs');
const path = require('path');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const emojis = require('../DataBaseJson/emojis.json');

const filaPath = path.join(__dirname, '../DataBaseJson/mediadores.json');
const cargosPath = path.join(__dirname, '../DataBaseJson/mediador.json');
const filasDadosPath = path.join(__dirname, '../DataBaseJson/filasDados.json');
const logsJsonPath = path.join(__dirname, '../DataBaseJson/logs.json');

const CARGO_MEDIADOR_ESPECIAL = '1462181979930755283';

async function adicionarMediadorAosLogsDePartidas(guild, userId, client) {
  try {
    if (!fs.existsSync(filasDadosPath)) return;
    const filasDados = JSON.parse(fs.readFileSync(filasDadosPath, 'utf-8'));

    let logsChannelId = null;
    if (fs.existsSync(logsJsonPath)) {
      const logsArr = JSON.parse(fs.readFileSync(logsJsonPath, 'utf-8'));
      logsChannelId = Array.isArray(logsArr) ? logsArr[0] : null;
    }

    for (const [canalId, partida] of Object.entries(filasDados)) {
      if (!partida || !partida.jogadores) continue;

      const jogadoresIDs = partida.jogadores.map(j => (typeof j === 'object' && j.id) ? j.id : j);

      if (logsChannelId) {
        try {
          const logChannel = await guild.channels.fetch(logsChannelId).catch(() => null);
          if (logChannel) {
            const embed = new EmbedBuilder()
              .setTitle('👮 Mediador Entrou no Painel')
              .setColor(0xF59E42)
              .setDescription(
                `<@${userId}> entrou no painel de mediadores e foi registrado na partida.\n\n` +
                `**Canal da Partida:** <#${canalId}>\n` +
                `**Jogadores:** ${jogadoresIDs.map(id => `<@${id}>`).join(' x ')}\n` +
                `**Modo:** ${partida.modo || 'Desconhecido'}\n` +
                `**Valor:** R$ ${partida.valor || '?'}`
              )
              .setFooter({ text: `ID do Mediador: ${userId}` })
              .setTimestamp();

            await logChannel.send({ embeds: [embed] });
          }
        } catch (e) {
          console.error('[MEDIADOR] Erro ao enviar log:', e.message);
        }
      }

      try {
        const canal = await guild.channels.fetch(canalId).catch(() => null);
        if (canal) {
          if (canal.isThread()) {
            await canal.members.add(userId).catch(() => {});
          } else {
            const { PermissionFlagsBits } = require('discord.js');
            await canal.permissionOverwrites.edit(userId, {
              ViewChannel: true,
              SendMessages: true,
              ReadMessageHistory: true
            }).catch(() => {});
          }
        }
      } catch (e) {
        console.error('[MEDIADOR] Erro ao adicionar ao canal:', e.message);
      }
    }
  } catch (e) {
    console.error('[MEDIADOR] Erro ao processar entrada no painel:', e.message);
  }
}

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (interaction.isButton()) {
            if (interaction.customId === 'entrar_fila' || interaction.customId === 'sair_fila') {
                let fila = [];
                if (fs.existsSync(filaPath)) {
                    try { fila = JSON.parse(fs.readFileSync(filaPath)); } catch (e) { fila = []; }
                    if (!Array.isArray(fila)) fila = [];
                }

                let cargosPermitidos = [];
                if (fs.existsSync(cargosPath)) {
                    try { cargosPermitidos = JSON.parse(fs.readFileSync(cargosPath)); } catch (e) {}
                }

                const userId = interaction.user.id;
                let mudou = false;

                if (interaction.customId === 'entrar_fila') {
                    const member = await interaction.guild.members.fetch(userId).catch(() => null);
                    if (!member) {
                        await interaction.reply({ content: '❌ Não foi possível verificar seus cargos.', ephemeral: true });
                        return;
                    }

                    const temCargoEspecial = member.roles.cache.has(CARGO_MEDIADOR_ESPECIAL);
                    const temCargo = temCargoEspecial || member.roles.cache.some(role => cargosPermitidos.includes(role.id));

                    if (!temCargo) {
                        await interaction.reply({
                            content: `${emojis.failuser_emoji || '❌'} Você precisa do cargo de mediador para entrar na fila!`,
                            ephemeral: true
                        });
                        return;
                    }

                    if (fila.includes(userId)) {
                        await interaction.reply({
                            content: `${emojis.failuser_emoji || '❌'} Você já está na fila de mediadores!`,
                            ephemeral: true
                        });
                        return;
                    }

                    fila.push(userId);
                    mudou = true;

                    if (temCargoEspecial) {
                        adicionarMediadorAosLogsDePartidas(interaction.guild, userId, interaction.client).catch(console.error);
                    }

                } else if (interaction.customId === 'sair_fila') {
                    if (!fila.includes(userId)) {
                        await interaction.reply({
                            content: `${emojis.failuser_emoji || '❌'} Você não está na fila de mediadores!`,
                            ephemeral: true
                        });
                        return;
                    }
                    fila = fila.filter(id => id !== userId);
                    mudou = true;
                }

                if (mudou) {
                    fs.writeFileSync(filaPath, JSON.stringify(fila, null, 2));
                }

                let desc = fila.length > 0
                    ? fila.map((u, index) => `**${index + 1}.** <@${u}>`).join('\n')
                    : 'Nenhum mediador na fila.';

                const embed = new EmbedBuilder()
                    .setTitle(`${emojis.information_emoji || 'ℹ️'} Fila de Mediadores`)
                    .setDescription('Entre ou saia da fila de mediadores usando os botões abaixo.')
                    .addFields({ name: `${emojis._people_emoji || '👥'} Mediadores na Fila (${fila.length}):`, value: desc })
                    .setColor(0x2ecc71);

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('entrar_fila')
                        .setLabel('Entrar na fila')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji(emojis.member_add_emoji || '➕'),
                    new ButtonBuilder()
                        .setCustomId('sair_fila')
                        .setLabel('Sair da fila')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji(emojis.member_remove_emoji || '➖')
                );

                await interaction.update({ embeds: [embed], components: [row] });
                return;
            }
        }

        if (!interaction.isChatInputCommand()) return;
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) {
            console.error(`Nenhum comando correspondente a ${interaction.commandName} foi encontrado.`);
            return;
        }
        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(error);
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: 'Houve um erro ao executar este comando!', ephemeral: true });
            } else {
                await interaction.reply({ content: 'Houve um erro ao executar este comando!', ephemeral: true });
            }
        }
    },
};
