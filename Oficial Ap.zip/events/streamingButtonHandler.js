module.exports = {
  async voltarStreamerParaFila(guild, jogadorId) {
    return;
  }
};
