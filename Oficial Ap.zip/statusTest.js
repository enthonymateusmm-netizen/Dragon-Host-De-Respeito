const { Client, GatewayIntentBits } = require('discord.js');
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildPresences
  ]
});

client.on('ready', () => {
  client.user.setPresence({
    activities: [{ name: 'Testando', type: 0 }],
    status: 'online'
  });
  console.log('Status setado!');
});

client.login('MTUxNTE5NjY0ODc2MDkzNDQwMA.GgHEYA.KZl-T5fcFXcZhMUHzcGLCWYHs0M-q7h5YtkIo0'); 